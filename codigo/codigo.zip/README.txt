Para ejecutar todo
python3 main.py -a

    Para seguir la ejecuci�n autom�tica del programa hace falta cerrar la gr�fica, 
    que sale al generar los dos algoritmos de clustering.

Para ejecutar solo el preproceso 
   python3 main.py -r
Para ejecutar solo jerarquico
   python3 main.py -s
Para ejecutar solo kmeans
   python3 main.py -t
Para ejecutar solo asociacion
   python3 main.py -u